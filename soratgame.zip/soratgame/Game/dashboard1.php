<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="dash-area">
        <img src="images/new.jpg" alt="" class="img-fluid">
        <div class="content-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="heading">
                        <ul>
                            <li>
                                <h2>LOGGED ID :- <a href="#">RK000214</a></h2>
                            </li>
                            <li>
                                <h2>POINTS :-<a href="#">20021.00</a></h2>
                            </li>
                            <li>
                                <h2>GAMES</h2>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <img src="images/1.png" alt="" class="setting-img hidden-xs">
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-2">
                        <img src="images/images.png" alt="" class="points-img">
                        <div class="point-heading text-center">
                            <h2><a href="#" data-toggle="modal" data-target="#fullHeightModalRight">Points</a></h2>

                            <!-- Full Height Modal Right -->
                            <div class="modal fade right" id="fullHeightModalRight" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-full-height modal-right" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title w-100" id="myModalLabel">Points Withdraw</h4>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="">
                                                <label class="amt">AMOUNT</label>
                                                <input type="text">
                                            </form>
                                        </div>
                                        <div class="modal-footer justify-content-center">
                                            <button type="button" class="btn-submit">Submit</button>
                                            <button type="button" class="btn-cl" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Full Height Modal Right -->

                        </div>

                    </div>
                    <div class="col-md-2 hidden-xs"></div>
                    <div class="col-md-3">
                        <img src="images/frame.png" alt="" class="frame-img">
                        <div class="frame-content">
                            <ul>
                                <li>
                                    <a href="#."><img src="images/game.png" alt=""></a>
                                </li>
                                <li>
                                    <a href="#.">
                                        <h2>Fun Target</h2>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="main">
                            <img src="images/f1.png">
                            <div class="header">
                                <ul>
                                    <li>
                                        <h2>Withdraw</h2>
                                    </li>
                                    <li>
                                        <h2>Status</h2>
                                    </li>
                                </ul>
                            </div>
                            <div class="dashboard-area">
                                <div class="dashboard-content text-center">
                                    <div class="tab-content" id="pills-tabContent">
                                        <div class="tab-pane fade show active" id="pills-pending" role="tabpanel" aria-labelledby="pills-pending-tab">
                                            <h2>40000</h2>
                                            <h2>Fail</h2>
                                        </div>
                                        <div class="tab-pane fade" id="pills-accepted" role="tabpanel" aria-labelledby="pills-accepted-tab">
                                            <h2>20000</h2>
                                            <h2>Pass</h2>
                                        </div>
                                        <div class="tab-pane fade" id="pills-rejected" role="tabpanel" aria-labelledby="pills-rejected-tab">
                                            <h2>80000</h2>
                                            <h2>Fail</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="dashboard-footer">
                                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                    <li>
                                        <button class="btn-def">Refresh</button>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link active" id="pills-pending-tab" data-toggle="pill" href="#pills-pending" role="tab" aria-controls="pills-pending" aria-selected="true">Pending</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="pills-accepted-tab" data-toggle="pill" href="#pills-accepted" role="tab" aria-controls="pills-accepted" aria-selected="false">Accepted</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="pills-rejected-tab" data-toggle="pill" href="#pills-rejected" role="tab" aria-controls="pills-rejected" aria-selected="false">Rejected</a>
                                    </li>

                                    <li>
                                        <button class="btn-def">Logout</button>
                                    </li>
                                </ul>
                            </div>
                            <!-- <div class="dashboard-area">

                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>




</html>