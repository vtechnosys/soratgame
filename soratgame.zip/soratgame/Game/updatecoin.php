<?php
include('config.php');
session_start();
$coin=$_GET['score'];
$id=$_SESSION['id'];
$sql="update tbl_user set coin='$coin' where id='$id'";
if(mysqli_query($con,$sql))
{
    $sql1="select coin from tbl_user where id='$id'";
    $rk=mysqli_query($con,$sql1);
    $rd=mysqli_fetch_row($rk);
    $_SESSION['coins']=$rd[0];
    echo $rd[0];

}
else
{
    echo mysqli_error($con);
}
?>