<?php 
include('../config.php');
$id=$_GET['id'];
$uid=$_GET['uid'];
$coin=$_GET['coin'];
$sql="update tbl_withdrawl set status='Rejected' where id=$id";
if(mysqli_query($con,$sql))
{
    header("Location:withdraw.php");
}
?>