<?php
include('../config.php');
$sql = "select * from tbl_withdrawl inner join tbl_user on tbl_withdrawl.uid=tbl_user.id where tbl_withdrawl.status='Rejected'";
$rs = mysqli_query($con,$sql);
while($rw=mysqli_fetch_row($rs))
{
    echo "<tr>
    <td> $rw[0] </td>
    <td> $rw[5] </td>
    <td> $rw[1] </td>
    <td> $rw[3] </td></tr>";
}                                            
?>