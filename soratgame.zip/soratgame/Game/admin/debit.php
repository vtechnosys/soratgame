<?php 
include('../config.php');
session_start();
$id=$_GET['id'];
$uid=$_GET['uid'];
$coin=$_GET['coin'];
$sql="update tbl_withdrawl set status='Accepted' where id=$id";
if(mysqli_query($con,$sql))
{
    $sql1="insert into tbl_transaction(details,uid,coins,dtside)values('coins withdraw','$uid','$coin','cr')";
    if(mysqli_query($con,$sql1))
    {
        $sql2="select * from tbl_user where id=$uid";
        $sq=mysqli_query($con,$sql2);
        $rw=mysqli_fetch_row($sq);
        $coins=$rw[4]-$coin;
        
        $sql3="update tbl_user set coin='$coins' where id=$uid";
        if(mysqli_query($con,$sql3))
        {
            $sql4="select * from tbl_user where id=$uid";
            $rk=mysqli_query($con,$sql4);
            $rw=mysqli_fetch_row($rk);
            $_SESSION['coins']=$rw[4];
            header('Location:withdraw.php');
        }
    }
    
}
?>