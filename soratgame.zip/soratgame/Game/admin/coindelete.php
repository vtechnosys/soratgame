<?php
$id=$_GET['id'];
include('../config.php');
session_start();
if(!isset($_SESSION['username']))
{
    header("Location:index.php");
}
$sql="delete from tbl_coin where id=$id";
if(mysqli_query($con,$sql))
{
    header('location:coin.php');
}
else
echo mysqli_error($con);

?>