<?php
include('../config.php');
session_start();
if(!isset($_SESSION['username']))
{
    header("Location:index.php");
}
$id=$_GET['id'];
$sql="update tbl_user set status='inactive' where id=$id";
if(mysqli_query($con,$sql))
{
    $coin=$_GET['coin'];
    $sql2="insert into tbl_transaction(details,uid,coins,dtside)values('coins received-removed','$id','$coin','cr')";
    if(mysqli_query($con,$sql2))
    {
        echo "<script>window.location.href='user.php';</script>";
    }
    else
    {
        echo mysqli_error($con);
    }
}
else
echo mysqli_error($con);

?>