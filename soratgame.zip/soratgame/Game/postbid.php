<?php
    include_once('config.php');
    session_start();
    $uid=$_SESSION['id'];
    $pos = $_GET['pos'];
    $amt = $_GET['amt'];
    $score=$_GET['score'];
    $sql = "select * from tbl_bid where status = 'active'";
    $rs = mysqli_query($con,$sql);
    $rw = mysqli_fetch_row($rs);
    $bid = $rw[0];
    
    $sql = "INSERT INTO `tbl_user_bid`( `uid`, `bid`, `pos`, `amt`) VALUES ('$uid','$bid','$pos','$amt')";
    if(mysqli_query($con,$sql))
    {
        $sql1="update tbl_user set coin='$score' where id=$uid";
        if(mysqli_query($con,$sql1))
        {
            $_SESSION['coins']=$score;
            echo "success";
        }
    }
    else
    {
        echo mysqli_error($con);
    }
?>