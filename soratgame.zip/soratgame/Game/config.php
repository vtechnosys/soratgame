<?php
	$con = mysqli_connect("localhost","vertextechnosys_vertexuser","?ODoHK?KXn]I","vertextechnosys_sorat");
?>