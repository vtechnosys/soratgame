<?php
    include('config.php');
    
    $flag = $_GET['flag'];
    if($flag == 'write')
    {
        $tm = $_GET['sec'];
        $sql = "select * from tbl_bid where status='inactive' order by bid_id desc limit 10";
        $s = "";
        $rs = mysqli_query($con,$sql);
        while($rw = mysqli_fetch_row($rs))
        {
            $s = $s.$rw[3].' ';
            
        }
        $fn = fopen('testing.txt','w');
        $txt = $tm."-".$s;
        fwrite($fn,$txt);
        //fclose();
    }
?>