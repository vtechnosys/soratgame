<?php
include('config.php');
session_start();
$uid=$_SESSION['id'];
    $score=$_GET['total'];
    $win=$_GET['win'];
        if($win==""||$win=='0')
        {
            $coins=$_SESSION['coins'];
            $sqql1="update tbl_user set coin='$coins' where id=$uid";
            if(mysqli_query($con,$sqql1))
            {
                $_SESSION['coins']=$score;
                echo $_SESSION['coins'];
            }
           
        }
        else
        {
            $sqql="update tbl_user set coin='$score' where id=$uid";
            if(mysqli_query($con,$sqql))
            {
                $_SESSION['coins']=$score;
                echo $_SESSION['coins'];
            }
        }
?>