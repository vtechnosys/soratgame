<?php
include('config.php');
session_start();
$tol=$_GET['tol'];
$id=$_SESSION['id'];
//echo $id;
$sql="update tbl_user set coin='$tol' where id='$id'";
if(mysqli_query($con,$sql))
{
    $sql2="select * from tbl_user where id='$id'";
    $rd=mysqli_query($con,$sql2);
    $rw=mysqli_fetch_row($rd);
    //echo $rw[4];
    $_SESSION['coins']=$rw[4];
    echo $_SESSION['coins'];
}
?>