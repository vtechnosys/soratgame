<?php
    include_once('config.php');
    session_start();
    if(isset($_POST['btn_log']))
    {
        $mob = $_POST['mob'];
        $ps = $_POST['ps'];
        $sql = "select * from tbl_user where username = '$mob' and password='$ps'";
        //echo $sql;
        //exit();
        $rs = mysqli_query($con,$sql);
        $user = array();
        if(mysqli_num_rows($rs)>0)
        {
            //echo "success";
            //exit();
            $rw = mysqli_fetch_row($rs);
            $_SESSION['id'] = $rw[0];
            $_SESSION['coins']=$rw[4];
            header("location:dashboard.php");
        }
        else{
            echo mysqli_error($con);
        }
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="gamepagecss.css">
    
</head>

<body>
    <div class="login">
        <img src="new.jpg" alt="" class="login-img">
        <div class="login-area">
            <div class="container-fluid">
                <form action="" method="post">
                    <div class="row">
                        <div class="col-md-12">
                            <h2>Response :- &nbsp; Please Login</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mx-auto text-center">
                            <img src="1.png" alt="img" height="300px" width="300px">
                        </div>
                    </div>
                    <!-- <div class="row">
                        <div class="col-md-2 thumb">
                            <img src="images/thumb.png" alt="" height="200px" width="100%">
                        </div>
                    </div> -->
                    <div class="row">
                        <div class="col-md-12 login-form text-center">
                            <div class="account">
                                <label for="fname">USERNAME</label>
                                <input type="text" placeholder="Username" name="mob">
                            </div>
                            <div class="password">
                                <label for="fname">PASSWORD</label>
                                <input type="password" placeholder="Password" name="ps">
                                <div class="enter-close">
                                    <button class="btn-enter" type="submit" name="btn_log">ENTER</button>
                                    <button class="btn-close">CLOSE</button>
                                </div>
                            </div>

                        </div>
                        <!-- <div class="col-md-12 text-center">
                            <button class="btn-enter">ENTER</button>
                            <button class="btn-enter">CLOSE</button>
                        </div> -->

                    </div>
                </form>
            </div>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>