<?php
    session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<body>
<div class="main">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<div class="score">
					<label class="text">Score</label>
					<div class="led-red">
						<button class="score_border" id='score'><?php echo $_SESSION['coins']; ?></button>
					</div>
				</div>
				<div class="time">
					<label class="text">Time</label>
					<div class="led-red">
						<label class="score_border" id="tmr">0 : 3</label>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div id="mainbox" class="main-box">
				<div class="golden-box">
					<div class="black-box">
						<div class="orange-box">
							<div id="box" class="box">
									<div class="box1">
										<span class="span1"><img src="icon1.png" class="icon1"></span>
										<span class="span2"><img src="icon2.png" class="icon2"></span>
										<span class="span3"><img src="icon3.png" class="icon3"></span>
										<span class="span4"><img src="icon4.png" class="icon4"></span>
										<span class="span5"><img src="icon1.png" class="icon5"></span>
										<span class="span6"><img src="icon2.png" class="icon6"></span>
										<span class="span7"><img src="icon3.png" class="icon7"></span>
										<span class="span8"><img src="icon4.png" class="icon8"></span>
										<span class="span9"><img src="icon1.png" class="icon9"></span>
										<span class="span10"><img src="icon3.png" class="icon10"></span>
									</div>
									<div class="box2">
										<span class="span11"><h1>1</h1></span>
										<span class="span12"><h1>9</h1></span>
										<span class="span13"><h1>8</h1></span>
										<span class="span14"><h1>3</h1></span>
										<span class="span15"><h1>0</h1></span>
										<span class="span16"><h1>5</h1></span>
										<span class="span17"><h1>6</h1></span>
										<span class="span18"><h1>2</h1></span>
										<span class="span19"><h1>7</h1></span>
										<span class="span20"><h1>4</h1></span>
									</div>
							</div>
							<div class="min">
								<div class="gold">
									<div class="inner-circle">
										<div class="min-slide">
											<img src="coins.png" id="hide" class="coin">
											<div class="owl-carousel owl-theme">
											    <div class="item"><img src="coins1.png" class="img-fluid"></div>
											    <div class="item"><img src="coins2.png" class="img-fluid"></div>
											    <div class="item"><img src="coins.png" style="height: 30px;width: 60%;margin-right: 8px;margin-top: 4px;"></div>
											    <div class="item"><img src="coins3.png" class="img-fluid"></div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			

		</div>
			<div class="col-md-3">
				<div class="win">
					<label class="text">Winner</label>
					<div class="led-red">
						<label class="score_border" id='win'>0</label>
					</div>
				</div>
				<div class="data">
					<label class="text">Last 10 Data</label>
					<div class="led-red">
						<label class="score_border" id="lst">1 2 3 4 5 6 7 8 9 </label>
					</div>
				</div>
				
			</div>
		</div>
	</div>


	<div class="main_1">
		<div class="container-fluid px-0">
			<div class="row">
				<div class="col-md-6">
					<div class="amount">
						<button class="num1" onclick="funopt(1)">1</button>
						<button class="num2" onclick="funopt(5)">5</button>
						<button class="num3" onclick="funopt(10)">10</button>
						<button class="num4" onclick="funopt(50)">50</button>
					</div>
				</div>
				<div class="col-md-6">
					<div class="amount_1">
						<button class="num1" onclick="funopt(100)">100</button>
						<button class="num2" onclick="funopt(500)">500</button>
						<button class="num3" onclick="funopt(1000)">1000</button>
						<button class="num4" onclick="funopt(5000)">5000</button>
					</div>
				</div>
			</div>
		</div>
		<div class="container-fluid">
				<div class="bet_button">
					<div class="row">
						<div class="col-md-2 px-0">
							<div class="take">
								<button class="take_btn" id='btn_take'>Take</button>
							</div>
						</div>
						<div class="col-md-2">
							<div class="cancel">
								<button class="cancel_btn"  onclick="cancelBet()">Cancel Bet</button>
							</div>
						</div>
						<div class="col-md-4">
							<div class="start">
								<!-- <img src="logo.png"> -->
								<!-- <button class="inner-btn" onclick=" myfunction(); myhide()" >Start</button> -->
								<a onclick=" myfunction(); myhide()"><button class="start_btn"></button></a>
							</div>
						</div>
						<div class="col-md-2">
							<div class="specific">
								<button class="specific_btn" onclick="specificBet()" >Cancel Specific Bet</button>
							</div>
						</div>
						<div class="col-md-2 px-0">
							<div class="ok">
								<button class="ok_btn" onclick="Betok()">Bet Ok</button>
							</div>
						</div>
					</div>
				</div>
		</div>
		<div class="labels">
			<div class="container-fluid">
				<div class="row justify-content-center" style="padding-left:30px;padding-right: 30px;">	
					<span>
						<div class="label_btn">
							<div class="label" id="lbl1" style="color:black;">0</div>
							<div class="circle-wrapper text-center">
								<div class="warning circle"></div>
									<button class="round-btn" onclick="funbit(1)">1</button>
							</div>
						</div>
					</span>
					<span>
						<div class="label_btn">
							<div class="label" id="lbl2" style="color:black;">0</div>
							<div class="circle-wrapper text-center">
								<div class="warning circle"></div>
									<button class="round-btn" onclick="funbit(2)">2</button>
							</div>
						</div>
					</span>
					<span>
						<div class="label_btn">
							<div class="label" id="lbl3" style="color:black;">0</div>
							<div class="circle-wrapper text-center">
								<div class="warning circle"></div>
									<button class="round-btn" onclick="funbit(3)">3</button>
							</div>
						</div>
					</span>
					<span>
						<div class="label_btn">
							<div class="label" id="lbl4" style="color:black;">0</div>
							<div class="circle-wrapper text-center">
								<div class="warning circle"></div>
									<button class="round-btn" onclick="funbit(4)">4</button>
							</div>
						</div>
					</span>
					<span>
						<div class="label_btn">
							<div class="label" id="lbl5" style="color:black;">0</div>
							<div class="circle-wrapper text-center">
								<div class="warning circle"></div>
									<button class="round-btn" onclick="funbit(5)">5</button>
							</div>
						</div>
					</span>
					<span>
						<div class="label_btn">
							<div class="label" id="lbl6" style="color:black;">0</div>
							<div class="circle-wrapper text-center">
								<div class="warning circle"></div>
									<button class="round-btn" onclick="funbit(6)">6</button>
							</div>
						</div>
					</span>
					<span>
						<div class="label_btn">
							<div class="label" id="lbl7" style="color:black;">0</div>
							<div class="circle-wrapper text-center">
								<div class="warning circle"></div>
									<button class="round-btn" onclick="funbit(7)">7</button>
							</div>
						</div>
					</span>
					<span>
						<div class="label_btn">
							<div class="label" id="lbl8" style="color:black;">0</div>
							<div class="circle-wrapper text-center">
								<div class="warning circle"></div>
									<button class="round-btn" onclick="funbit(8)">8</button>
							</div>
						</div>
					</span>
					<span>
						<div class="label_btn">
							<div class="label" id="lbl9" style="color:black;">0</div>
							<div class="circle-wrapper text-center">
								<div class="warning circle"></div>
									<button class="round-btn" onclick="funbit(9)">9</button>
							</div>
						</div>
					</span>
					<span>
						<div class="label_btn">
							<div class="label" id="lbl0" style="color:black;">0</div>
							<div class="circle-wrapper text-center">
								<div class="warning circle"></div>
									<button class="round-btn" onclick="funbit(0)">0</button>
							</div>
						</div>
					</span>
				</div>
			</div>
		</div>
		<div class="over">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-2">
								<div class="take" style="width: 70px;">
									<button class="take_btn" id='cns'>0</button>
								</div>
							</div>
							<div class="col-md-8">
								<div class="over_btn">
									<button class="over_btn_text" id="btnover">
										You Can Bet Now
									</button>
								</div>
							</div>
							<div class="col-md-2">
								<div class="ok" style="width: 70px;float: right;">
									<div class="ok_btn">
										<a href="dashboard.php" style="text-decoration:none;color:white;">Exit</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>	

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script>
	var opt =0;
	var ch="";
	var tm=0;
	var ch;
	var win;
	var spc=0;
	var betok=0;
	var cancelbet=0;
	fetch('testing.txt')
          .then(response => response.text())
          .then(data => {
          	// Do something with your data
          	obj = data.split('-');
          	console.log(obj[0]);
          	tm = obj[0];
          	$('#lst').html(obj[1]);
          	test=obj[1].split(' ');
          			//alert(test[0]);
					var x = 1024; //min value
            		var y = 9000; //max value
            		var deg;
					if(test[0] == 0)
                    {
            		    deg = Math.floor(0.55 * (x - y))+ y;
                    }
                    else if(test[0] == 1)
                    {
                        deg = Math.floor(0.6 * (x - y))+ y;
                    }
                    else if(test[0] == 2)
                    {
                        deg = Math.floor(0.56 * (x - y))+ y;
                    }
                    else if(test[0] == 3)
                    {
                        deg = Math.floor(0.7 * (x - y))+ y;
                    }
                    else if(test[0] == 4)
                    {
                        deg = Math.floor(1.2 * (x - y))+ y;
                    }
                    else if(test[0] == 5)
                    {
                        deg = Math.floor(1.25 * (x - y))+ y;
                    }
                    else if(test[0] == 6)
                    {
                        deg = Math.floor(1.57 * (x - y))+ y;
                    }
                    else if(test[0] == 7)
                    {
                        deg = Math.floor(0.853 * (x - y))+ y;
                    }
                    else if(test[0] == 8)
                    {
                        deg = Math.floor(1 * (x - y))+ y;
                    }
                    else if(test[0] == 9)
                    {
                        deg = Math.floor(0.5 * (x - y))+ y;
                    }
				
				    document.getElementById('box').style.WebkitTransitionDuration = "0.01s";
				    
					document.getElementById('box').style.webkitTransform = "rotate("+deg+"deg)";
          	timerCh();
          });
    function funopt(optval){
        opt = optval;
        spc=0;
    }
    function cancelBet()
	{
        cancelbet=1;
        if(betok==0)
        {
            if(tm > 15)
            {
                $amt1=parseInt($('#score').html()) + parseInt($('#cns').html());
				$.ajax({
                    url:'updatecoin.php?score='+$amt1,
                    success:function(data)
                    {
                        
                    },
                    error:function(data)
                    {
                                
                    }
                });
				location.reload();
            }
        }
        
    }
    function specificBet()
    {
        spc=1;
    }
    function Betok()
    {
        betok=1;
        $("#btnover").html('Your Bet has been Accepted');
    }
    
    function funbit(chs)
    {
        if(betok==0)
        {
            
            if(tm > 15)
			{
            	if(spc==0)
            	{
                    $prv=parseInt($('#cns').html());
                    <?php
                    $coin=$_SESSION['coins'];
                    if($coin > 0)
                    {
                    ?>
                    
                        lblamt = parseInt($('#lbl'+chs).html())
                        $('#lbl'+chs).html(lblamt+parseInt(opt));
                        $amt = parseInt($('#score').html());
                        ch = chs;
                        $amt=$prv+parseInt(opt);
                        $('#cns').html($amt);
                        $amt1=<?php echo $_SESSION['coins'];?> - parseInt($('#cns').html());
                        $("#score").html($amt1);
                        $.ajax({
                            url:'postbid.php?pos='+ch+'&amt='+opt+'&score='+$amt1,
                            success:function(data)
                            {
                                
                            },
                            error:function(data)
                            {
                                
                            }
                        });
                    <?php  
                    }
                  ?>
				 
                }
				else 
				{
                tempamt = parseInt($('#lbl'+chs).html());
				$amt = parseInt($('#cns').html());
				//alert(tempamt);
				//alert($amt);
				$rem=$amt-tempamt;
				//alert($rem);
               // $amt = $amt+tempamt;
             	$('#lbl'+chs).html(0);  
			   	$('#cns').html($rem);
				$coin=parseInt($('#score').html());
				$tol=$coin+tempamt;
				//alert($tol);
				$.ajax({
					url:'addscore.php?tol='+$tol,
					success:function(data)
					{
						$("#score").html(data);
					},
					error:function(data)
					{
						alert(data);
					}
				});
				}
			}
		}
        
    }
    function timerCh()
    {
        if(tm==0)
        {
            fetch('testing.txt')
          .then(response => response.text())
          .then(data => {
          	// Do something with your data
          	obj = data.split('-');
          	console.log(obj[0]);
          	tm = obj[0];
          	$('#lst').html(obj[1]);
			  		
					//document.getElementById('box').style.transform = "rotate(270deg)";
					
          });
        }
        $('#tmr').html("0:"+tm);
        tm = tm-1;
        if(tm == 50){
            var win=parseInt($('#win').html());
            var score=parseInt($('#score').html());
            var total=win+score;
            //$("#score").html(total);
            $.ajax({
            		   url:'bittimeupdate.php?total='+total+'&win='+win,
            		   success:function(data){
            		        $('#score').html(data);
            		      // for(i=0; i<=9; i++)
                            //{
                              //  $('#lbl'+i).html(0);
                            //}
            		   }
            		});
            $("#win").html(0);
        }
        else if(tm == 0)
        {
            myfunction();
            fetchWin();
            $('#cns').html(0);
            
        }
        else if(tm==15)
        {
            $("#btnover").html('Your Bet has been Accepted');
        }
        setTimeout(timerCh,950);
        
        
    }
    function fetchWin()
    {
        
        	$.ajax({
                url:'bidoperation.php?flag=win',
                success:function(data)
                {
                    
                    var x = 1024; //min value
            		var y = 9000; //max value
            		var deg;
					if(data == 0)
                    {
            		    deg = Math.floor(0.55 * (x - y))+ y;
                    }
                    else if(data == 1)
                    {
                        deg = Math.floor(0.6 * (x - y))+ y;
                    }
                    else if(data == 2)
                    {
                        deg = Math.floor(0.56 * (x - y))+ y;
                    }
                    else if(data == 3)
                    {
                        deg = Math.floor(0.7 * (x - y))+ y;
                    }
                    else if(data == 4)
                    {
                        deg = Math.floor(1.2 * (x - y))+ y;
                    }
                    else if(data == 5)
                    {
                        deg = Math.floor(1.25 * (x - y))+ y;
                    }
                    else if(data == 6)
                    {
                        deg = Math.floor(1.57 * (x - y))+ y;
                    }
                    else if(data == 7)
                    {
                        deg = Math.floor(0.853 * (x - y))+ y;
                    }
                    else if(data == 8)
                    {
                        deg = 0;
                        //deg = Math.floor(1 * (x - y))+ y;
                    }
                    else if(data == 9)
                    {
                        deg = Math.floor(0.5 * (x - y))+ y;
                    }
                    document.getElementById('box').style.WebkitTransitionDuration = "5s";
            		document.getElementById('box').style.webkitTransform = "rotate("+deg+"deg)";
            		var amt = parseInt($('#lbl'+data).html()) * 10;
            		$('#win').html(amt);
            		var total=parseInt($('#score').html());
            		$("#score").html(total);
            		
            		$.ajax({
            		   url:'bidoperation.php?flag=sc&amt='+amt+'&total='+total,
            		   success:function(data){
            		       //$('#score').html(data);
            		       for(i=0; i<=9; i++)
                            {
                                $('#lbl'+i).html(0);
                            }
            		   }
            		});
                    fetch('testing.txt')
                      .then(response => response.text())
                      .then(data => {
                      	// Do something with your data
                      	obj = data.split('-');
                      	console.log(obj[0]);
                      	//tm = obj[0];
                      	$('#lst').html(obj[1]);
                      	//timerCh();
                      });
                },
                error:function(data)
                {
                    
                }
            });
        
		
    }
    $('#btn_take').click(function(){
        var tamt = parseInt($('#score').html()) + parseInt($('#win').html());
        //$('#score').html("0")
        
        $('#score').html(tamt);
        $('#cns').html(0);
       var win=parseInt($('#win').html());
       $.ajax({
            		   url:'bittimeupdate.php?total='+tamt+'&win='+win,
            		   success:function(data){
            		        $('#score').html(data);
            		      // for(i=0; i<=9; i++)
                            //{
                              //  $('#lbl'+i).html(0);
                            //}
            		   }
            		});
            		
             $('#win').html(0);		
        
    })
	function myfunction() {
	    /*$.ajax({
                url:'gameoperation.php?flag=write&sec='+tm,
                success:function(data)
                {
                    tm = tm-1;
                },
                error:function(data)
                {
                    
                }
            });*/
		var x = 1024; //min value
		var y = 9000; //max value

		var deg = Math.floor(0.853* (x - y))+ y;
		document.getElementById('box').style.transform = "rotate("+deg+"deg)";

        /*
        8=1
        9=0.5
        1=0.6
        2=0.56
        3=0.7
        4=1.2
        5=1.57
        6=0.577
        7=0.853
        0=0.55
        
    
        */
		// var element = document.getElementById('manibox');
		// element.classList.remove('animate');
		// setTimeout(function(){
		// 	element.classList.add('animate');
		// }, 5000);
	}

	function myfun(){
	$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    rtl:true,
    nav:false,
    dots:false,
    autoplay:true,
    autoplayTimeout:800,
    items:1
	})
    
	}
	
</script>

</body>
</html>