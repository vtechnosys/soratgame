<?php
    include_once('config.php');
    $uid=$_POST['uid'];
    $pos = $_POST['pos'];
    $amt = $_POST['amt'];
    $sql = "select * from tbl_bid where status = 'active'";
    $rs = mysqli_query($con,$sql);
    $rw = mysqli_fetch_row($rs);
    $bid = $rw[0];
    
    $sql = "INSERT INTO `tbl_user_bid`( `uid`, `bid`, `pos`, `amt`) VALUES ('$uid','$bid','$pos','$amt')";
    if(mysqli_query($con,$sql))
    {
        echo "success";
    }
    else
    {
        echo mysqli_error($con);
    }
?>