<?php
    include('config.php');
    $flag = $_POST['flag'];
    if($flag == 'new')
    {
        $sql = "update tbl_bid set status='inactive'";
        mysqli_query($con,$sql);
        $stm=$_POST['s'];
        $etm=$_POST['e'];
        $sql = "insert into tbl_bid(bid_start_time,bid_end_time) values('$stm','$etm')";
        if(mysqli_query($con,$sql))
        {
            echo "success";
        }
        else{
            echo mysqli_error($con);
        }
    }
    if($flag=="update")
    {
        $pos = $_POST['pos'];
        $sql = "update tbl_bid set win_pos='$pos' where status='active'";
        if(mysqli_query($con,$sql))
        {
            $sql = "update tbl_bid set status='inactive'";
            mysqli_query($con,$sql);
            echo "success";
        }
        else
        {
            echo mysqli_error($con);
        }
    }
    
?>