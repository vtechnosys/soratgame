<?php

    include('config.php');
    
    
    
    $sql = "select * from tbl_bid where status = 'active'";
    $rs = mysqli_query($con,$sql);
    $rw = mysqli_fetch_row($rs);
    $bid = $rw[0];
    $flag = $_GET['flag'];
    $res = array();
    if($flag == "cnt")
    {
        for($i=0;$i<10;$i++)
        {
            $sql = "select count(*) from tbl_user_bid where pos = '$i' and bid = '$bid'";
            $rs = mysqli_query($con,$sql);
            if(mysqli_num_rows($rs)>0)
            {
                while($rw = mysqli_fetch_row($rs))
                {
                    $data['cnt'] = $rw[0];
                    array_push($res,$data);
                }
            }
            else
            {
                $data['cnt'] = 0;
                array_push($res,$data);
            }
        }
        echo json_encode($res);
    }
    else if($flag == "get")
    {
        $pos = $_GET['pos'];
        $sql = "select * from tbl_user_bid as b join tbl_user as u on b.uid = u.id where bid = '$bid' and pos = '$pos'";
        //echo $sql;
        //exit();
        $rs = mysqli_query($con,$sql);
        echo mysqli_error($con);
        $res = array();
        while($rw = mysqli_fetch_row($rs))
        {
            $data['sr'] = $rw[0];
            $data['uid'] = $rw[1];
            $data['unm'] = $rw[8];
            $data['upi'] = $rw[10];
            $data['mob'] = $rw[9];
            $data['pos'] = $rw[3];
            $data['amt'] = $rw[4];
            array_push($res,$data);
        }
        echo json_encode($res);
    }
    if($flag == 'win')
    {
        $sql = "SELECT * FROM `tbl_bid` WHERE win_pos <> 'NA' ORDER by bid_id DESC LIMIT 10";
        $rs = mysqli_query($con,$sql);
        $res = array();
        while($rw = mysqli_fetch_row($rs))
        {
            $data['win_pos'] = $rw[3];
            $data['dt'] = $rw[4];
            array_push($res,$data);
        }
        echo json_encode($res);
    }
    if($flag == 'mybids')
    {
        $uid = $_GET['uid'];
        $sql = "select * from tbl_user_bid where uid='$uid' and bid='$bid'";
        $rs = mysqli_query($con,$sql);
        echo mysqli_error($con);
        $res = array();
        while($rw = mysqli_fetch_row($rs))
        {
            $data['pos']=$rw[3];
            $data['amt']=$rw[4];
            array_push($res,$data);
        }
        echo json_encode($res);
    }
?>