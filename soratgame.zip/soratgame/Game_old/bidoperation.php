<?php
    include('../config.php');
    $flag = $_GET['flag'];
    if($flag == 'new')
    {
        $sql = "update tbl_bid set status='inactive'";
        mysqli_query($con,$sql);
        $stm="3";
        $etm="4";
        $sql = "insert into tbl_bid(bid_start_time,bid_end_time) values('$stm','$etm')";
        if(mysqli_query($con,$sql))
        {
            echo "success";
        }
        else{
            echo mysqli_error($con);
        }
    }
    if($flag=="update")
    {
        //$pos = $_GET['pos'];
        $sql = "select * from tbl_bid where status='active'";
        $rs = mysqli_query($con,$sql);
        $rw = mysqli_fetch_row($rs);
        $bid = $rw[0];
        $sql = "SELECT bid,pos, COUNT(uid) as c FROM `tbl_user_bid` where bid='$bid' GROUP BY pos ORDER BY c ASC";
        $rs = mysqli_query($con,$sql);
        $rw = mysqli_fetch_row($rs);
        $rw = mysqli_fetch_row($rs);
        $pos = $rw[1];
        $sql = "update tbl_bid set win_pos='$pos' where status='active'";
        if(mysqli_query($con,$sql))
        {
            $sql = "update tbl_bid set status='inactive'";
            mysqli_query($con,$sql);
            echo "success";
        }
        else
        {
            echo mysqli_error($con);
        }
    }
    else if($flag == 'win'){
        $sql = "select * from tbl_bid where status='inactive' order by bid_id desc";
        $rs = mysqli_query($con,$sql);
        $rw = mysqli_fetch_row($rs);
        $win = $rw[3];
        echo $win;
    }
    
    
?>