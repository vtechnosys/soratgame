<?php
    include_once('../config.php');
    $uid=$_POST['id'];
    $pos = $_GET['pos'];
    $amt = $_GET['amt'];
    $sql = "select * from tbl_bid where status = 'active'";
    $rs = mysqli_query($con,$sql);
    $rw = mysqli_fetch_row($rs);
    $bid = $rw[0];
    
    $sql = "INSERT INTO `tbl_user_bid`( `uid`, `bid`, `pos`, `amt`) VALUES ('$uid','$bid','$pos','$amt')";
    if(mysqli_query($con,$sql))
    {
        echo "success";
    }
    else
    {
        echo mysqli_error($con);
    }
?>