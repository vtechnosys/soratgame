<?php
$id=$_GET['id'];
$con = mysqli_connect("localhost","vertextechnosys_vertexuser","?ODoHK?KXn]I","vertextechnosys_sorat");
$sql="delete from tbl_user where id=$id";
if(mysqli_query($con,$sql))
{
    header('location:user.php');
}
else
echo mysqli_error($con);

?>