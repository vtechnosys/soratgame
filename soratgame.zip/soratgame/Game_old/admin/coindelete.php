<?php
$id=$_GET['id'];
$con = mysqli_connect("localhost","vertextechnosys_vertexuser","?ODoHK?KXn]I","vertextechnosys_sorat");
$sql="delete from tbl_coin where id=$id";
if(mysqli_query($con,$sql))
{
    header('location:coin.php');
}
else
echo mysqli_error($con);

?>