<?php
    include_once('config.php');
    $flag = $_POST['flag'];
    if($flag == 'register')
    {
        $nm = $_POST['nm'];
        $mob = $_POST['mob'];
        $st = $_POST['upi'];
        $ps = $_POST['ps'];
        
        $sql = "INSERT INTO `tbl_user`(`username`, `mobile`, `upi`, `password`) values('$nm','$mob','$st','$ps')";
        if(mysqli_query($con,$sql))
        {
            echo "success";
        }
        else{
            echo mysqli_error($con);
        }
        
    }
    else if($flag=="login"){
        $mob = $_POST['mob'];
        $ps = $_POST['ps'];
        $sql = "select * from tbl_user where mobile = '$mob' and password='$ps'";
        //echo $sql;
        //exit();
        $rs = mysqli_query($con,$sql);
        $user = array();
        if(mysqli_num_rows($rs)>0)
        {
            //echo "success";
            //exit();
            $rw = mysqli_fetch_row($rs);
            $data['msg']="success";
            $data['uid'] = $rw[0];
            $data['nm'] = $rw[1];
            $data['mob'] = $rw[2];
            $data['upi'] = $rw[3];
            $data['ps'] = $rw[4];
            array_push($user,$data);
            echo json_encode($user);
        }
        else{
            echo mysqli_error($con);
        }
    }
?>